#!/usr/bin/env bash
set -euo pipefail
if [[ -e group_vars/vault.yml ]]; then
  echo "group_vars/vault.yml already exists; use ansible-vault edit." >&2
  exit 1
fi
cp group_vars/vault.yml.example group_vars/vault.yml
ansible-vault encrypt group_vars/vault.yml
