#!/usr/bin/env bash
set -euo pipefail
: "${SPLUNK_HEC_ENDPOINT:?Set SPLUNK_HEC_ENDPOINT}"
: "${SPLUNK_HEC_TOKEN:?Set SPLUNK_HEC_TOKEN}"
: "${SPLUNK_INDEX:?Set SPLUNK_INDEX}"
curl --fail --silent --show-error \
  -H "Authorization: Splunk ${SPLUNK_HEC_TOKEN}" \
  -H "Content-Type: application/json" \
  "${SPLUNK_HEC_ENDPOINT}" \
  -d "{\"event\":\"otel-hec-connectivity-test\",\"index\":\"${SPLUNK_INDEX}\",\"sourcetype\":\"otel:test\",\"source\":\"otel-ansible-project\"}"
echo
