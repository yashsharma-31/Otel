#!/usr/bin/env bash
set -euo pipefail
if [[ ! -f ansible-otel.env ]]; then
  echo "Missing ansible-otel.env. Copy ansible-otel.env.example and configure it." >&2
  exit 1
fi
chmod 600 ansible-otel.env
set -a
# shellcheck disable=SC1091
source ./ansible-otel.env
set +a
exec ansible-playbook "$@"
