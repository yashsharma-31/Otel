# OpenShift 4.20 + OpenTelemetry + Splunk Enterprise (Ansible)

An Ansible project to:
1. Install Red Hat build of OpenTelemetry Operator using OLM.
2. Create a narrowly scoped SCC and RBAC for a node-level filelog DaemonSet.
3. Deploy an OpenTelemetry Collector Contrib image with filelog + OTLP receivers.
4. Export OpenShift container logs and Ansible callback traces/logs to Splunk Enterprise HEC.
5. Optionally expose OTLP/HTTP through an OpenShift Route protected by a bearer token.

> **Important support boundary:** The Red Hat Operator is installed from `redhat-operators`. This project uses the upstream `otel/opentelemetry-collector-contrib` image because it includes `filelog`, `k8sattributes`, `bearertokenauth`, and `splunk_hec`. Confirm the chosen image/version with your organization's image policy and support requirements. The Operator's presence does not make a community Collector image Red Hat-supported.
>
> **OpenShift node log access:** reading `/var/log/pods` requires a hostPath mount and UID 0 in this baseline. A custom SCC is created with only `/var/log/pods` allowed as a read-only host path. SELinux policy on your nodes may still deny access; test on a non-production cluster and have the cluster security team review the SCC. Do not replace it with the broad `privileged` SCC as a shortcut.
>
> **OpenShift 4.20:** the project uses the documented OLM package `opentelemetry-product`, channel `stable`, source `redhat-operators`, namespace `openshift-opentelemetry-operator`. Verify catalog availability before running. OLM subscription upgrades are automatic by default; adjust `installPlanApproval` to `Manual` if required by change control.

## Architecture

- Collector DaemonSet tails `/var/log/pods/*/*/*.log` on every schedulable node.
- File path is parsed to derive pod namespace/name/UID/container, then `k8sattributes` enriches the resource.
- An OTLP receiver accepts Ansible callback logs and traces.
- `splunk_hec` sends logs and traces to Splunk Enterprise HEC.
- An optional Route exposes only OTLP/HTTP. The receiver uses bearer-token authentication. Keep the Route disabled unless you need a control node outside the cluster to send telemetry, and set an IP allowlist if your router supports it.

## Prerequisites

Control node:
- `oc` CLI matching OpenShift 4.20 and logged in as a cluster administrator (or a delegated identity with all required permissions).
- Python 3.10+ and Ansible.
- Network access to the OpenShift API, image registry, and Splunk HEC.
- Python packages: `kubernetes`, `PyYAML`, `opentelemetry-api`, `opentelemetry-sdk`, `opentelemetry-exporter-otlp`.
- `kubernetes.core` Ansible collection.

Cluster:
- OLM and `redhat-operators` catalog available.
- Egress from Collector pods to Splunk HEC endpoint.
- Splunk HEC enabled, token created with the target index allowed, and TLS certificate trusted by Collector.
- Splunk HEC endpoint normally looks like `https://splunk.example.com:8088/services/collector`. If Splunk uses a private CA, add that CA to the Collector image's system trust bundle or extend the Collector manifest with a mounted CA bundle before deploying.

## Quick start

```bash
# 1. Extract archive and enter project
cd openshift-otel-splunk-ansible

# 2. Install dependencies
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
ansible-galaxy collection install -r collections/requirements.yml

# 3. Verify OpenShift access
oc whoami
oc get clusterversion version -o jsonpath='{.status.desired.version}{"\n"}'
oc get catalogsource -n openshift-marketplace redhat-operators

# 4. Create encrypted credentials
cp group_vars/vault.yml.example group_vars/vault.yml
ansible-vault encrypt group_vars/vault.yml
# Edit encrypted values later with: ansible-vault edit group_vars/vault.yml

# 5. Edit group_vars/all.yml
# Set Splunk HEC URL, index, Collector image, and (if needed) Route options.

# 6. Deploy
ansible-playbook playbooks/site.yml --ask-vault-pass

# 7. Inspect
oc get pods -n observability -o wide
oc get opentelemetrycollector -n observability
oc logs -n observability -l app.kubernetes.io/name=otel-collector --all-containers=true --prefix
```

## Credentials

`group_vars/vault.yml` must contain:

```yaml
vault_splunk_hec_token: "YOUR_SPLUNK_HEC_TOKEN"
vault_ansible_otel_token: "A_LONG_RANDOM_BEARER_TOKEN"
```

Generate a token, for example:

```bash
openssl rand -hex 32
```

Never commit the unencrypted file or a real token. The playbook creates:
- `splunk-hec-secret` with key `hec-token`
- `otel-ansible-auth` with key `bearer-token`

## Optional external Ansible callback

If the Ansible control node is outside the cluster, the in-cluster service DNS name is not reachable from it. Two options:
1. Run the playbook from a pod/runner with access to `otel-collector-collector.observability.svc:4318`; or
2. Set `enable_otel_route: true`, set `otel_route_ip_whitelist` to your control node's public/NAT CIDR(s), and use the HTTPS Route endpoint.

The Route is disabled by default. The bearer token is required by the Collector receiver, but it is not a replacement for network restriction. Avoid exposing OTLP ingestion broadly.

After deployment, get the route hostname (if enabled):

```bash
oc get route otel-ansible-ingest -n observability -o jsonpath='https://{.spec.host}{"\n"}'
```

Create `ansible-otel.env` from `ansible-otel.env.example`, set the route endpoint and the same bearer token used in Vault, then:

```bash
set -a
source ./ansible-otel.env
set +a
ansible-playbook -i ansible/inventory.ini ansible/site.yml
```

The callback is opt-in through `ANSIBLE_CALLBACKS_ENABLED=otel` in `ansible-otel.env`. The callback plugin is based on `parseablehq/ansible-otel-demo` (Apache-2.0), adapted for authenticated OTLP delivery. Its telemetry is sent to the cluster Collector, which exports it to Splunk.

## Splunk searches

```spl
index=<your_index> source=openshift
```

```spl
index=<your_index> sourcetype="kube:container:logs"
```

```spl
index=<your_index> source=ansible-otel
```

The Splunk HEC exporter maps OpenTelemetry log records and spans into HEC events. Confirm the actual event fields and sourcetype in your Splunk version and adjust the exporter metadata as needed.

## Operational cautions

- The default `start_at: end` avoids replaying old node logs after first start. Change to `beginning` only if you explicitly want historical replay and understand the ingestion/cost impact.
- Filelog checkpoints require persistent storage for reliable restart behavior. This starter uses an `emptyDir`-backed Collector state directory; a Collector pod replacement can cause re-reading or missed offsets. For production, add a per-node persistent hostPath volume for the filelog storage directory and validate ownership/SELinux.
- The Collector image version is pinned in `group_vars/all.yml`; update it deliberately after compatibility testing.
- Kubernetes API enrichment needs cluster-wide read-only access to pods/namespaces/replicasets.
- HEC index must exist and the HEC token must be authorized for it.
- This is a starter implementation; test RBAC/SCC, SELinux, TLS trust, image pull policy, and HEC ingestion in a non-production cluster first.

## Rollback

```bash
ansible-playbook playbooks/destroy.yml --ask-vault-pass
```

This removes the Collector CR, namespace resources, SCC binding, custom SCC, and Operator subscription/group/namespace. Review the playbook before using it: deleting the Operator namespace removes the Operator installation.
